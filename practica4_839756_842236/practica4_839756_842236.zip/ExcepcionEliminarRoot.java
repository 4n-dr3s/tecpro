// Autores: Andrei Vlasceanu [839756] & Andres Yubero [842236]

public class ExcepcionEliminarRoot extends ExcepcionArbolFicheros {
    public ExcepcionEliminarRoot() {
        super("No se puede eliminar el directorio raíz");
    }

}
