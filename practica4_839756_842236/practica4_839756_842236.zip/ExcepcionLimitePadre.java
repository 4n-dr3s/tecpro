// Autores: Andrei Vlasceanu [839756] & Andres Yubero [842236]

public class ExcepcionLimitePadre extends ExcepcionArbolFicheros {
    public ExcepcionLimitePadre() {
        super("Fuera de los límites. No existe el nodo padre");
    }
}
