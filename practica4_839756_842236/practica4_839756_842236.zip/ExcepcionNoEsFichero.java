// Autores: Andrei Vlasceanu [839756] & Andres Yubero [842236]

public class ExcepcionNoEsFichero extends ExcepcionArbolFicheros {
    public ExcepcionNoEsFichero() {
        super("No es un fichero");
    }
}
