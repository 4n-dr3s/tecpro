// Autores: Andrei Vlasceanu [839756] & Andres Yubero [842236]

public class ExcepcionNoExisteNodo extends ExcepcionArbolFicheros {
    public ExcepcionNoExisteNodo() {
        super("No existe el nodo al que apunta el path");
    }
}
