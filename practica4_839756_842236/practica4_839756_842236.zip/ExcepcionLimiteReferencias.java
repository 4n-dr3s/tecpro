// Autores: Andrei Vlasceanu [839756] & Andres Yubero [842236]

public class ExcepcionLimiteReferencias extends ExcepcionArbolFicheros {
    public ExcepcionLimiteReferencias() {
        super("Limite de referencias alcanzado");
    }
}