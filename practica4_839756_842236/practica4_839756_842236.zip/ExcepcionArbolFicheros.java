// Autores: Andrei Vlasceanu [839756] & Andres Yubero [842236]

abstract class ExcepcionArbolFicheros extends Exception {
    public ExcepcionArbolFicheros(String mensaje) {
        super(mensaje);
    }
}
