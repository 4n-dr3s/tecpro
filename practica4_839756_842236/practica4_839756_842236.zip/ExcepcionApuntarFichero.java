// Autores: Andrei Vlasceanu [839756] & Andres Yubero [842236]

public class ExcepcionApuntarFichero extends ExcepcionArbolFicheros {
    public ExcepcionApuntarFichero() {
        super("No se puede apuntar a un fichero");
    }
}
