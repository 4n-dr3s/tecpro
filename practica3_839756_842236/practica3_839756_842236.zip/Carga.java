// Autores: Andrei Vlasceanu [839756] & Andres Yubero [842236]

// La interfaz Carga representa objetos que pueden ser cargados en un camión
public interface Carga extends Guardable {

}